import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  // { path: 'home', component: HomeComponent },
  // {
  //   path: 'demo',
  //   loadChildren: () => import('./demo/demo.module').then((m) => m.DemoModule),
  // },
  // {
  //   path: 'counter',
  //   loadChildren: () =>
  //     import('./counter/counter.module').then((m) => m.CounterModule),
  // },
  {
    path: 'posts',
    loadChildren: () =>
      import('./posts/posts.module').then((m) => m.PostsModule),
  },
  {
    path: '',
    redirectTo: '/posts',
    pathMatch: 'full',
  },
  { path: '**', redirectTo: '/posts' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
