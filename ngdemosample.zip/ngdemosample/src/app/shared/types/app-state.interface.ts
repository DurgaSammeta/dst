import { PostStateInterface } from "src/app/posts/store/types/post.interface";

export interface AppStateInterface {
  posts: PostStateInterface;
}
