import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostService } from '../../services/post.service';

@Component({
  selector: 'app-edit-post',
  templateUrl: './edit-post.component.html',
  styleUrls: ['./edit-post.component.scss']
})
export class EditPostComponent implements OnInit {
  post: any;
  constructor(private route: ActivatedRoute, private postService: PostService, private router: Router) { }

  ngOnInit(): void {
    const postId = this.route.snapshot.paramMap.get('postId');

    this.postService.getPost(postId)
      .subscribe(post => {
        this.post = post;
      });
  }

  updatePost(val) {
    this.postService.updatePost(this.post.id, val).subscribe(() => {
      this.router.navigateByUrl('/posts');
    });
  }
}
