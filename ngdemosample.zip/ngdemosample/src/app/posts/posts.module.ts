import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { PostsRoutingModule } from './posts-routing.module';
import { PostsComponent } from './components/posts/posts.component';
import { AddPostComponent } from './components/add-post/add-post.component';
import { EditPostComponent } from './components/edit-post/edit-post.component';
import { PostService } from './services/post.service';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { postReducer } from './store/posts.reducers';
import { PostsEffect } from './store/effects/posts.effects';


@NgModule({
  declarations: [PostsComponent, AddPostComponent, EditPostComponent],
  imports: [
    CommonModule,
    PostsRoutingModule,
    HttpClientModule,
    FormsModule,
    StoreModule.forFeature('posts', postReducer),
    EffectsModule.forFeature([PostsEffect]),
  ],
  providers: [
    PostService
  ]
})
export class PostsModule { }
