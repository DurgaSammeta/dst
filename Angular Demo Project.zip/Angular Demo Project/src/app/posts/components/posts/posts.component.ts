import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.scss']
})
export class PostsComponent implements OnInit {
  posts = [];
  constructor(private postService: PostService) { }

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData() {
    this.postService.getPosts()
      .subscribe((posts: any) => {
        this.posts = posts;
      });
  }

  removePost(post) {
    this.postService.removePost(post.id)
    .subscribe((posts: any) => {
      // this.posts = this.posts.filter(res => res.id !== post.id);
      // this.posts = posts;
      this.posts.splice(this.posts.indexOf(post), 1);
    });
  }

}
